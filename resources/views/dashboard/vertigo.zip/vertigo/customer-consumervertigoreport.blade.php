@include('include.sidebar')

<div class="container mt-5">
<input type="hidden" id="consumer_id" value="{{request()->get('id')}}"/>

    <h2 class="mb-4">Consumer Medical Details</h2>
    <table class="table data-table table-bordered yajra-datatable">
        <thead>
            <tr>
                <th>No</th>
                <th>Created at </th>
                <th>CN Number</th>
                <th>Consumer Name</th>
                <th>Consumer Mobile Number</th>
                {{-- <th>Cunsumer Image</th> --}}
                <th>Consumer Test Report</th>
                
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script>
 $(function() {
    let id=$('#consumer_id').val();
    var csrfToken = document.head.querySelector('meta[name="csrf-token"]').content;
var table = $('.data-table').DataTable({
   
  
    processing: true,
    serverSide: true,
  
    ajax: {
        url:"{{ route('consumer-customer-vertigo-report') }}",
        type: "post",
        data: {
            _token: csrfToken,
            "id": id
        }
    },
    columns: [{
            data: 'DT_RowIndex',

        },
        {
            data: 'created_at',
            name: 'created_at'
        },
        {
            data: 'certification_no',
            name: 'certification_no'
        },
        {
            data: 'consumer_name',
            name: 'consumer_name'
        },
        {
            data: 'consumer_mob',
            name: 'consumer_mob'
        },
       
        // {
        //     data: 'consumerImage',
        //     name: 'consumerImage'
        // },

        {
            data: 'consumertest',
            name: 'consumertest',
            orderable: false,
            searchable: false
        },
 
 
    ]
});



});




    </script>

@include('include.footer') 