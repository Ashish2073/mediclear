@include('include.sidebar')
<style>
    * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  /* background-color: #c7c7cd !important; */
  background-color: #f8f9fc !important;
}
.text-black {
  color: black;
  font-size: 20px;
  font-weight: 600;
}
body {
  font-family: "Montserrat", sans-serif !important;
}
.check-box {
  font-size: 25px;
  color: #5a5c69;
}

.form-check-input {
  border: 1px solid #5a5c69 !important;
}

    </style>
<div class="container">
    <form class="row g-3 ">
      <div class="col-md-6">
        <label for="inputEmail4" class="form-label">Name</label>
        <input type="email" class="form-control" id="inputEmail4" />
      </div>
      <div class="col-md-6">
        <label for="inputPassword4" class="form-label">Company</label>
        <input type="password" class="form-control" id="inputPassword4" />
      </div>
      <div class="col-12">
        <label for="inputAddress" class="form-label">Location</label>
        <input
          type="text"
          class="form-control"
          id="inputAddress"
          placeholder="1234 Main St"
        />
      </div>
      <div class="col-12">
        <label for="inputAddress2" class="form-label">Phone Number</label>
        <input
          type="text"
          class="form-control"
          id="inputAddress2"
          placeholder="8656656565"
        />
      </div>
      <div class="col-md-6">
        <label for="inputCity" class="form-label">Aadhar Number</label>
        <input type="text" class="form-control" id="inputCity" />
      </div>
      <div class="col-md-4">
        <label for="inputState" class="form-label">Address</label>
        <select id="inputState" class="form-select">
          <option selected>Choose...</option>
          <option>...</option>
        </select>
      </div>
      <div class="col-md-2">
        <label for="inputZip" class="form-label">Zip</label>
        <input type="text" class="form-control" id="inputZip" />
      </div>

      <div class="col-12">Gender</div>
      <div class="col-12">
        <div class="form-check form-check-inline">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />

          <label class="form-check-label" for="inlineCheckbox1">Male</label>
        </div>
        <div class="form-check form-check-inline">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox2"
            value="option2"
          />
          <label class="form-check-label" for="inlineCheckbox2">Female</label>
        </div>
        <div class="form-check form-check-inline">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox3"
            value="option3"
          />
          <label class="form-check-label" for="inlineCheckbox3"
            >Others
          </label>
        </div>
      </div>
    </form>
  </div>
  <!-- form end -->
  <!-- another form -->
  <section class="mt-5">
    <div class="container">
      <p class="text-black">
        To be filled by the candidate before Medical Examination :
      </p>
      <p>
        A. When you are "dizzy" do you experience any of the following
        symptoms ? (check yes or no)
      </p>
      <div class="row my-4">
        <div class="col-6">
          1. Light-headness or swimmimg sensation in the head?
        </div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">2. Blacking out or loss of conciousness?</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">3. Object stunning or tuning around you?</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">4. Nausea or vomiting?</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">
          5. tingling in your fingers, toes or around your mouth?
        </div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">
          6. tingling in your fingers, toes or around your mouth?
        </div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">
          7. tingling in your fingers, toes or around your mouth?
        </div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />&nbsp;&nbsp;&nbsp;
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container">
      <p class="text-black">Past Medical History :</p>
      <p>
        1. Do you have a History of any of the following ? please check all
        that apply
      </p>
      <div class="container">
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox1"
            >Heart disease</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
        <div class="form-check form-check-inline">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox2"
            value="option2"
          />
          <label class="form-check-label" for="inlineCheckbox2"
            >Hypertension</label
          >
        </div>
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox3"
            >Kidney disease</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox3"
            value="option3"
            disabled
          />
        </div>
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox3"
            >Thyroid disease</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox3"
            value="option3"
          />
        </div>
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox3"
            >Migrain headaches</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox3"
            value="option3"
          />
        </div>
      </div>

      <p class="my-5">
        2. Do you have a History of any of the following symptoms? please
        check all that apply
      </p>
      <p>a. Difficulty in hearing ?</p>
      <div class="container">
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox1"
            >Left ear</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
        <div class="form-check form-check-inline">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox2"
            value="option2"
          />
          <label class="form-check-label" for="inlineCheckbox2"
            >Both ears</label
          >
        </div>
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox3"
            >Right ears</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox3"
            value="option3"
          />
        </div>
        <div class="form-check form-check-inline">
          <label class="form-check-label" for="inlineCheckbox3"
            >associated width attack</label
          >
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox3"
            value="option3"
          />
        </div>
      </div>
    </div>
    <div class="container">
      <p class="text-black my-3">Complaints :</p>

      <div class="row my-4">
        <div class="col-6">1. Giddiness</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">2. Vertigo</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">3. Nausea</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">4. Seizure Disorder (Epilespy)</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">5. Acrophobia</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">6. Assthama / COPD</div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
      <div class="row my-4">
        <div class="col-6">
          7. tingling in your fingers, toes or around your mouth?
        </div>
        <div class="col-4">
          <input
            class="form-check-input"
            type="checkbox"
            id="inlineCheckbox1"
            value="option1"
          />
        </div>
      </div>
    </div>
  </section>

@include('include.footer') 