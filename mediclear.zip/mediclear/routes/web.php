<?php

use App\Http\Controllers\Company;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\ComplaintController;
use App\Http\Controllers\CorporateController;
use App\Http\Controllers\CustomerBatchController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DocterController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Route::get('/dashbord', function () {
    return view('dashboard.index');
})->middleware(['auth', 'verified'])->name('dashbord');





Route::middleware('auth')->group(function () {


    //company routes
    Route::get('/corporateID', [CorporateController::class, 'showCorporateID']);
    Route::post('/addCorporateID', [CorporateController::class, 'addCorporateID']);
    Route::get('/updateStatusCorporateID/{type}/{id}', [CorporateController::class, 'updateStatusCorporateID']);
    Route::post('/corporateID/delete', [CorporateController::class, 'deleteCorporateID']);
    Route::post('/corporateID/update', [CorporateController::class, 'updateCorporateID']);
    //end company routes


    // company routes
    Route::get('/add-company', [CompanyController::class, 'showCompany']);
    Route::post('/create-company', [CompanyController::class, 'CreateCompany'])->name('create_company');
    Route::post('/company/delete', [CompanyController::class, 'deleteCompany']);
    Route::post('/company/update', [CompanyController::class, 'updateCompany']);
    Route::get('/updateStatusCompany/{type}/{id}', [CompanyController::class, 'updateStatusCompany']);
    // end company routes



    // Doctor routes
    Route::get('/add-docter', [DoctorController::class, 'showDocter']);
    Route::post('/adddocter', [DoctorController::class, 'addDocter']);
    // end Docter Routes



//custmer routes
Route::get('/customer-profile', [CustomerController::class, 'showCustomer']);
Route::get('/updateStatusCustomer/{type}/{id}', [CustomerController::class, 'updateStatusCustomer']);
//end custmer routes


// feedback routes
Route::get('/feedback', [FeedbackController::class, 'showFeedback']);
Route::post('/feedback/delete', [FeedbackController::class, 'deleteFeedback']);
// end feedback routes


// complaint routes
Route::get('/complaint', [ComplaintController::class, 'showComplaint']);
Route::post('/complaint/delete', [ComplaintController::class, 'deleteComplaint']);
// end complaint routes



// Notifications
Route::get('/customer-notification', [NotificationController::class, 'customerNotification']);
Route::post('/sendNotification', [NotificationController::class, 'sendNotification']);

//end Notification



// batch routes
Route::get('/customer-batch', [CustomerBatchController::class, 'customerBatch']);

// end batch routes






    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');


});




require __DIR__.'/auth.php';
