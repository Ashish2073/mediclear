<?php

use App\Http\Controllers\API\CompanyController;
use App\Http\Controllers\API\Corporate_auth_controller;
use App\Http\Controllers\API\Customer_auth_controller;
use App\Http\Controllers\API\FeedbackController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::post('Customer/login', [Customer_auth_controller::class,'login']);
Route::post('Customer/register', [Customer_auth_controller::class,'register']);
Route::post('Corporate/login', [Corporate_auth_controller::class,'login']);


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});



Route::post('/feedback',[FeedbackController::class,'feedbackDetail'])->middleware('auth:sanctum');
Route::post('/company',[CompanyController::class,'companyDetail'])->middleware('auth:sanctum');
