<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerBatchController extends Controller
{
    //

public function customerBatch(){

    return view('dashboard.customerbatch');
}


}
