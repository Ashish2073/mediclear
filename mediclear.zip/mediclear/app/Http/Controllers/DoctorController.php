<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DoctorController extends Controller
{
    //

    public function showDocter(){

        return view('dashboard.add-doctor');
    }



    public function addDocter(Request $request){


        if(empty($request->sign)){
            return redirect()->back()->with('message',"Signature is required");
            // return response()->json(['status'=>'fail','message'=>"Signature is required"]);
        }else{


            $image = $request->file('sign');
            $imageName5 = date('Y-m-d H:i:s').'.' . $image->extension();
            $image->storeAs('public/images', $imageName5);

        }




        $doctor= new Doctor();
        $doctor->name=$request->name;
        $doctor->email=$request->email;
        $doctor->mobile_no=$request->mobile_no;
        $doctor->post=$request->post;
        $doctor->sign=$imageName5;
        $doctor->save();

        return ;
    }




}
