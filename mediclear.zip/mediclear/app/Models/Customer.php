<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
    use HasFactory ,HasApiTokens,Notifiable;

    // protected $guard="customer";
    protected $table="customers";

    protected $fillable =[
        'name',
        'email',
        'mobile_no',
        'address',
        'status',
        'user_id',
        'password',
    ];
}
