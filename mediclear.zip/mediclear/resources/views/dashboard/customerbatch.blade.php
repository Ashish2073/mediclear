@include('include.sidebar')
<!-- add company -->

<style>
    body {
        background-image: none;
    }

    .table,
    th {
        font-size: 15px !important;
        font-family: 'Poppins', sans-serif !important;
    }

    .dt-button {
        background-color: #1cc88a !important;
        background-image: linear-gradient(180deg, #1cc88a 10%, #13855c 100%) !important;
        background-size: cover !important;
        color: #fff !important;
        border: none !important;

    }



    .content-wrapper {
        margin-left: 210px;
        font-size: 19px;

    }
/*
    .btn {
        background-color: #1cc88a;
    }

    .btn:hover {
        background-color: #01796F !important;

    } */

    .sidebar-right-trigger {
        display: none;
    }

    /* input[type="file"] {
        display: none;

    } */

    /* .file {
        display: inline-block;
        color: #ffffff;
        background: orange;
        text-align: center;
        padding: 15px 40px;
    } */

    /* .input-group-text {
        margin-top: 5px;
    } */
</style>
{{--
        <!-- Main content starts -->
        <div class="container-fluid">
s
            <div class="d-flex justify-content-between">
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4 class="text-dark fw-bold   text-start h2" style="margin-top:80px;">Customer Batch</h4>
                            <!-- <nav aria-label="breadcrumb">
                                <ol class="breadcrumb bg-white">
                                    <li class="breadcrumb-item"><a href="#"> <i class="fa-solid fa-house text-secondary"></i></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"> <span class="text-dark ">Customer Batch</span></li>
                                </ol>
                            </nav> -->

                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb bg-white">
                                    <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house text-secondary"></i></a></li>
                                    <li class="breadcrumb-item text-decoration-none text-dark"><a href="#" class="text-dark">Batch Create</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Customer Batch</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- butns -->

                <div class="row  " style="margin-top:100px;">
                    <div class="col-md-7 ">
                        <div class="row">
                            <div class="col-md-4  text-center d-flex multiple-btn">
                                <button class="btn text-white " type="submit" style="margin-left: 10px;">Copy</button>
                                <button class="btn text-white " type="submit" style="margin-left: 10px;">CSV</button>
                                <button class="btn  text-white " type="submit" style="margin-left: 10px;">Excel</button>
                                <button class="btn  text-white " type="submit" style="margin-left: 10px;">PDF</button>
                                <button class="btn text-white  " type="submit" style="margin-left: 10px;">Print</button>
                            </div>

                        </div>

                    </div>
                </div>

            </div>
            <!--  -->

            <!-- end
        </div>

 --}}



                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h3 class="h3 mb-2 text-gray-800">Customer Batch</h3>



                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb bg-white">
                                        <li class="breadcrumb-item"><a href="#"><i class="fa-solid fa-house text-secondary"></i></a></li>
                                        <li class="breadcrumb-item text-decoration-none text-dark"><a href="#" class="text-dark">Batch Create</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Customer Batch</li>
                                    </ol>
                                </nav>




        <!--  3 -row start block -->
            <div class="row dashboard-header">
                <div class="col-md-12">
                    <div class="row mt-3">
                        <div class="col-md-12 boder-danger me-5 pe-5">
                            <div class="row mb" style="margin-bottom: 30px;">
                                <div class="col-sm-1">
                                    <p class="text-dark"><b><strong>Filters:</strong></b></p>
                                </div>
                                <div class="col-sm-3 end-date">
                                    <p class="text-dark"><strong>Date From:</strong></p>
                                    <div class="input-group date d-flex" id="datepicker1">
                                        <input type="text" class="form-control" id="date" placeholder="dd-mm-yyyy" />
                                        <span class="input-group-append">
                                            <span class="input-group-text bg-light d-block">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                        </span>
                                    </div>
                                </div>

                                <!--  -->
                                <!--  -->
                                <!--  -->
                                <div class="col-sm-3 end-date">
                                    <p class="text-dark"><strong>Date to:</strong></p>
                                    <div class="input-group date d-flex" id="datepicker2">
                                        <input type="text" class="form-control" id="date" placeholder="dd-mm-yyyy" />
                                        <span class="input-group-append">
                                            <span class="input-group-text bg-light d-block">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                        </span>
                                    </div>
                                </div>

                                <!--  -->
                                <div class="col-md-1 text-end" style="margin-left: 10px; margin-top:47px;">
                                    <button class="btn  bg-gradient-success text-white shadow-lg " type="submit">Filter</button>
                                </div>
                                <div class="col-md-1 " style="margin-left: -12px;  margin-top:47px;">
                                    <button class="btn bg-gradient-success text-white shadow-lg " type="submit">Reset</button>
                                </div>
                                <div class="col-sm-2" style="position: relative; top: 47px;">
                                    <div class="Click-here"> <button class="btn    bg-gradient-success text-white shadow-lg" type="submit" style="padding: 4px 4px; font-size:17px; width:165px;" data-target=" #mymodel" data-toggle="modal">+ Add Customer</button>




                                        <!-- poppux box start -->
                                        <div class="modal mt-4" id="mymodel">
                                            <div class="modal-dialog m-auto">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <form action="" class="text-center">
                                                            <span class="h3 mt-0 text-decoration-underline"> ADD Customer </span>
                                                            <br />
                                                            <br />
                                                            <label for="">Customer Name </label>
                                                            <input type="text" style="margin-right: 20px; margin-bottom:10px;" /> <br />
                                                            <label for="">Customer Batch No. </label>
                                                            <input type="text" style="margin-right: 40px;margin-bottom:10px;" /> <br />
                                                            <label for="">Total Test </label>
                                                            <input type="text" style="margin-left: 20px;margin-bottom:10px;" /> <br />
                                                            <label for="">City Name &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            <input type="text" style="margin-bottom:10px;" /> <br />
                                                            <label for="">Email ID &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            <input type="text" style="margin-bottom:10px;" /> <br />
                                                            <label for="">Phone NO. &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            <input type="text" style="margin-bottom:10px;" /> <br />
                                                            <button type="button" class="btn text-white" style="margin-left: 378px;margin-bottom:10px;">
                                                                ADD
                                                            </button>
                                                        </form>

                                                        <button type="btn" class="close" data-dismiss="modal">&times;</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>





                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--  -->




                        <div class="card-body" style=" width: -webkit-fill-available;">
                        <table class="display nowrap " id="example">
                            <thead class="text-white">
                                <tr style="border-bottom:3px solid black; font-weight:9px;">
                                    <th scope="col">Sr. No.</th>
                                    <th scope="col">Create Date</th>
                                    <th scope="col"> Customer Name</th>
                                    <th scope="col">Company Batch No.</th>
                                    <th scope="col">Total Test</th>
                                    <th scope="col">Email ID</th>
                                    <th scope="col">Phone No.</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <th scope="row">1</th>
                                    <td>11-22-2</td>
                                    <td>Rohit</td>
                                    <td>65</td>
                                    <td>7</td>
                                    <td>7656656565</td>
                                    <td>Aligarh@554gmail.com</td>
                                    <td class="text-success" style="font-size:1rem;">
                                        <div class="select">
                                            <select name="format" id="format">
                                                <option value="pdf">Active</option>
                                                <option value="txt">deactive</option>

                                            </select>
                                    </td>
                                    <td>
                                        <i class="fa-solid fa-pen-to-square" style="font-size:1rem;"></i>
                                        <i class="fa-solid fa-trash" style="font-size:1rem;"></i>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                        </div>
                    </div>





<!-- datepicker code -->

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

<script>
    // Initialize datepickers
    $('#datepicker1, #datepicker2, #datepicker3').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true
    });
</script>


@include('include.footer')
