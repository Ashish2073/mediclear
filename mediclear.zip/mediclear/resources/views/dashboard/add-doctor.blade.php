@include('include.sidebar')



@if (session()->has('message'))
    <script>
        alert('{{ session()->get('message') }}');
    </script>

    {{ session()->forget('message') }}
@endif



<style>
    .dt-button {
        background-color: #1cc88a !important;
        background-image: linear-gradient(180deg, #1cc88a 10%, #13855c 100%) !important;
        background-size: cover !important;
        color: #fff !important;
        border: none !important;

    }
</style>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h3 class="h3 mb-2 text-gray-800">Doctor</h3>

<!-- DataTales Example -->


        <!--  3 -row start block -->
            <div class="row dashboard-header">
                <div class="col-md-12">
                    <div class="row mt-3">
                        <div class="col-md-12 boder-danger me-5 pe-5">
                            <div class="row mb" style="margin-bottom: 30px;">
                                <div class="col-sm-1">
                                    <p class="text-dark"><b><strong>Filters:</strong></b></p>
                                </div>
                                <!-- <div class="col-sm-3 end-date">
                           <p class="text-dark"><strong>Date From:</strong></p>
                           <div class="input-group date d-flex" id="datepicker">
                              <input type="text" class="form-control " id="date" placeholder="dd-mm-yyyy" />
                              <span class="input-group-append">
                                 <span class="input-group-text bg-light d block ">
                                    <i class="fa fa-calendar"></i>
                                 </span>

                              </span>
                           </div>
                        </div> -->
                                <!--  -->
                                <!--  -->
                                <div class="col-sm-3 end-date">
                                    <p class="text-dark"><strong>Date From:</strong></p>
                                    <div class="input-group date d-flex" id="datepicker1">
                                        <input type="text" class="form-control" id="date" placeholder="dd-mm-yyyy" />
                                        <span class="input-group-append">
                                            <span class="input-group-text bg-light d-block">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                        </span>
                                    </div>
                                </div>

                                <!--  -->
                                <!--  -->
                                <!--  -->
                                <div class="col-sm-3 end-date">
                                    <p class="text-dark"><strong>Date to:</strong></p>
                                    <div class="input-group date d-flex" id="datepicker2">
                                        <input type="text" class="form-control" id="date" placeholder="dd-mm-yyyy" />
                                        <span class="input-group-append">
                                            <span class="input-group-text bg-light d-block">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                        </span>
                                    </div>
                                </div>

                                <!--  -->
                                <!--  -->
                                <!--  -->
                                <!-- <div class="col-sm-3 end-date">
                                    <p class="text-dark"><strong>Date From:</strong></p>
                                    <div class="col-sm-4 ">
                                        <input type="date" placeholder="dd-mm-yyyy!important;" class=" rounded  border-0 shadow-lg p-1 " style="background-color:#dc9727; " />
                                    </div>
                                </div> -->
                                <!-- <div class="col-sm-3 end-date">
                                    <p class="text-dark"><strong>Date to:</strong></p>
                                    <div class="col-sm-4 ">
                                        <input type="date" placeholder="dd-mm-yyyy!important;" class=" rounded  border-0 shadow-lg p-1 " style="background-color:#dc9727; " />
                                    </div>
                                </div> -->



                                <!-- <div class="col-sm-3 end-date">
                           <p><strong class="text-dark">Date to:</strong></p>
                           <div class="input-group date d-flex" id="datepicker1">
                              <input type="text" class="form-control" id="date" placeholder="dd-mm-yyyy" />
                              <span class="input-group-append">
                                 <span class="input-group-text bg-light d-block">
                                    <i class="fa fa-calendar"></i>
                                 </span>
                              </span>
                           </div>
                        </div> -->
                                <!--  -->


                                <!--  -->
                                <div class="col-md-1 text-end" style="margin-left: 10px; margin-top:47px;">
                                    <button class="btn   bg-gradient-success text-white shadow-lg " type="submit">Filter</button>
                                </div>
                                <div class="col-md-1 " style="margin-left: -12px;  margin-top:47px;">
                                    <button class="btn bg-gradient-success text-white shadow-lg " type="submit">Reset</button>
                                </div>
                                <div class="col-sm-2" style="position: relative; top: 47px;">
                                    <div class="Click-here"> <button class="btn   bg-gradient-success text-white shadow-lg" type="submit" style="padding: 4px 8px; font-size:17px;" data-target=" #mymodel" data-toggle="modal">+ Add Doctor</button>
                                        <!-- poppux box start -->
                                        <div class="modal mt-4" id="mymodel">
                                            <div class="modal-dialog m-auto">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <form action="{{url('adddocter')}}" method="POST" class="text-center">
                                                            @csrf
                                                            <span class="h3 mt-0 text-decoration-underline">
                                                                ADD DOCTOR
                                                            </span> <br> <br>
                                                            <label for="">Doctor Name </label>
                                                            <input type="text" name="name" style="margin-left:9px; margin-bottom:10px"> <br>
                                                            <label for="">Post Name &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            <input type="text" name="post" style="margin-bottom:10px;"> <br>


                                                            <label for="">Email ID &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            <input type="text" name="email" style="margin-bottom:10px;"> <br>
                                                            <label for="">Phone NO. &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            <input type="text" name="mobile_no" style="margin-bottom:10px;"> <br>
                                                            <div class="d-flex ">
                                                                <span style="margin-left:50px; f">Sign Upload</span>&nbsp;&nbsp;
                                                                <input style="width:240px; margin-bottom:5px; margin-bottom:10px"  name="sign" type="file" id="formFileMultiple">
                                                            </div>


                                                            <button type="submit" class="btn bg-gradient-success text-white shadow-lg" style="margin-left:378px">ADD</button>

                                                        </form>








                                                        <button type="btn" class="close" data-dismiss="modal">
                                                            &times;
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>









                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--  -->



                        <div class="card-body">
                            <table id="example" class="display nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>S No.</th>
                                        <th>Create Date</th>
                                        <th>Doctor Name</th>
                                        <th>Post</th>
                                        <th>Sign</th>
                                        {{-- <th>User ID</th> --}}
                                        {{-- <th>Password</th> --}}
                                        <th>Status</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>10/11/2023</td>
                                        <td>Ram </td>
                                        <td>+91 980786545</td>
                                        <td>amrit.bmdu@gmail.com</td>
                                        {{-- <td>MED001</td> --}}
                                        {{-- <td>*********23</td> --}}

                                        <td>
                                            <div class="dropdown mb-4">
                                                <button class="btn btn-warning dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                Select
                                                </button>
                                                <div class="dropdown-menu animated--fade-in"
                                                    aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item" href="#">Active</a>
                                                    <a class="dropdown-item" href="#">Deactive</a>

                                                </div>
                                            </div>

                                        </td>
                                        <td> <i class="fa-solid fa-pen-to-square text-success" style="font-size:1rem;"></i> &nbsp; <i class="fa-solid fa-trash text-danger" style="font-size:1rem;"></i></td>
                                    </tr>








                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="medi-footer bg-gradient-success">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap5'
        });
    </script>
@include( 'include.footer')
